make clean compile optimize 
make run_cli GEN_TYPE=i2cmb_generator_directed_test TEST_SEED=random
make run_cli GEN_TYPE=i2cmb_generator_random_test PLUS_ARGS=+DISABLE_PREDICTOR TEST_SEED=random
make run_cli GEN_TYPE=i2cmb_generator_i2c_operation TEST_SEED=random
make merge_coverage 
make view_coverage
